"""Oferta de transporte público (trenes) — sistema cíclico.

Portado de `titirilquen-repo/app.py:184-253`. Frecuencia endógena según tramo
crítico; tiempo de espera base `30/f_op` con penalización BPR-like si la
estación se satura.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True)
class TrainSupplyResult:
    t_acceso_min: NDArray[np.float64]
    t_espera_min: NDArray[np.float64]
    t_viaje_min: NDArray[np.float64]
    frecuencia_operativa: float
    #: Frecuencia ANTES del recorte: `carga_maxima / capacidad_tren`. Junto con
    #: `frecuencia_operativa` dice si `frec_min`/`frec_max` estan mordiendo y
    #: cuanto falta para que dejen de hacerlo. Sin esto la UI no puede
    #: distinguir «subi el tope y no paso nada» de «el tope no estaba activo»
    #: (AT-08/AT-09): cuando la frecuencia esta topada el efecto Mohring esta
    #: agotado, `frec_min` es irrelevante y la BPR de anden si muerde.
    frecuencia_teorica: float
    carga_por_tramo: NDArray[np.float64]
    estaciones_km: NDArray[np.float64]


def oferta_tren(
    *,
    demanda: NDArray[np.float64],
    L_ciudad_km: float,
    x_centro_km: float,
    v_tren_kmh: float,
    capacidad_tren: int,
    num_estaciones: int,
    v_caminata_kmh: float,
    frec_min: float,
    frec_max: float,
    tiempo_detencion_min: float = 0.5,
    anden_alpha: float = 0.15,
    anden_beta: float = 4.0,
    excluir_estacion_cbd: bool = False,
) -> TrainSupplyResult:
    N = len(demanda)
    dx = L_ciudad_km / N
    x_parcelas = np.arange(N) * dx + (dx / 2)

    dist_entre_est = L_ciudad_km / num_estaciones
    estaciones = np.unique(
        np.concatenate(
            [
                np.arange(x_centro_km, L_ciudad_km + 0.01, dist_entre_est),
                np.arange(x_centro_km, -0.01, -dist_entre_est),
            ]
        )
    )
    # Tolerancia en los bordes: el arange hacia la izquierda deja la estación
    # extrema en −1,8e−15 cuando el espaciado no es exacto en binario (20 km con
    # N = 6 o 14), y un filtro `>= 0` estricto la descartaba mientras su espejo
    # en 20 km sí entraba: la red quedaba asimétrica respecto del CBD.
    eps = 1e-9
    estaciones = np.clip(
        estaciones[(estaciones >= -eps) & (estaciones <= L_ciudad_km + eps)], 0.0, L_ciudad_km
    )
    estaciones = np.sort(estaciones)
    num_s = len(estaciones)

    pax_suben = np.zeros(num_s)
    dist_acceso = np.zeros(N)
    loc_estacion_acceso = np.zeros(N)
    idx_estacion_usuario = np.zeros(N, dtype=int)

    idx_cbd_parcela = int((x_centro_km / L_ciudad_km) * N)
    # `excluir_estacion_cbd` (especificación `umbrales="suaves"`, ver
    # demand/utility.py): fuera de la celda del CBD, la estación del CBD no es de
    # acceso, porque bajarse ahí es el destino. La celda a menos de media
    # interestación del centro accede por la siguiente, y la dominancia suave de
    # la utilidad decide cuánto vale ese metro. Sin la exclusión, esas celdas
    # tienen `tren_viaje = 0` y el metro sale del conjunto (D-69).
    idx_centro_est = int(np.argmin(np.abs(estaciones - x_centro_km)))
    for i in range(N):
        dists = np.abs(estaciones - x_parcelas[i])
        if excluir_estacion_cbd and i != idx_cbd_parcela and num_s > 1:
            dists[idx_centro_est] = np.inf
        idx_est = int(np.argmin(dists))
        dist_acceso[i] = dists[idx_est]
        loc_estacion_acceso[i] = estaciones[idx_est]
        idx_estacion_usuario[i] = idx_est
        if i != idx_cbd_parcela:
            pax_suben[idx_est] += demanda[i]

    carga_por_tramo = np.zeros(num_s - 1) if num_s >= 2 else np.zeros(0)
    carga_al_salir_estacion = np.zeros(num_s)

    acum = 0.0
    for i in range(idx_centro_est):
        acum += pax_suben[i]
        if i < len(carga_por_tramo):
            carga_por_tramo[i] = acum
            carga_al_salir_estacion[i] = acum

    acum = 0.0
    for i in range(num_s - 1, idx_centro_est, -1):
        acum += pax_suben[i]
        if i - 1 >= 0:
            carga_por_tramo[i - 1] = acum
            carga_al_salir_estacion[i] = acum

    carga_maxima = float(np.max(carga_por_tramo)) if len(carga_por_tramo) > 0 else 0.0
    f_teorica = carga_maxima / capacidad_tren if capacidad_tren > 0 else 0.0
    f_op = float(np.clip(f_teorica, frec_min, frec_max))

    capacidad_maxima_sistema = frec_max * capacidad_tren
    t_espera_base = (1 / (2 * f_op)) * 60 if f_op > 0 else 0.0

    t_espera_por_estacion = np.zeros(num_s)
    for i in range(num_s):
        if i == idx_centro_est:
            t_espera_por_estacion[i] = 0.0
            continue
        carga_local = carga_al_salir_estacion[i]
        ratio = carga_local / capacidad_maxima_sistema if capacidad_maxima_sistema > 0 else 0.0
        # BPR continua: sin salto ni caída en ρ=1. Con β alto el castigo es
        # despreciable bajo saturación (ρ<1) y crece suave al pasar ρ=1.
        factor = 1.0 + anden_alpha * (ratio**anden_beta)
        t_espera_por_estacion[i] = t_espera_base * factor

    t_acceso_min = (dist_acceso / v_caminata_kmh) * 60
    t_espera_min = t_espera_por_estacion[idx_estacion_usuario]
    # Tiempo en vehículo = marcha + detenciones. Las paradas que el viajero
    # sufre son las INTERMEDIAS: no la de subida (ya está adentro) ni la del CBD
    # (se baja). Sin este término, agregar estaciones acortaba el acceso sin
    # ningún costo — ver el comentario de `tiempo_detencion_min` en config.py.
    paradas_intermedias = np.maximum(np.abs(idx_estacion_usuario - idx_centro_est) - 1, 0)
    t_marcha_min = (np.abs(loc_estacion_acceso - x_centro_km) / v_tren_kmh) * 60
    t_viaje_min = t_marcha_min + paradas_intermedias * tiempo_detencion_min
    # Hubo aquí un `t_total = acceso + espera + viaje` que se devolvía y nadie
    # leía: cada consumidor suma los tres tramos por su cuenta, porque los
    # necesita separados para descomponer el costo generalizado.
    #
    # Y un parámetro `tasa_carga` (pax/s de subida) que solo se asignaba a `_`.
    # Estaba reservado para un dwell dependiente de los pasajeros que suben —
    # una deseconomía de escala del metro, que juega EN CONTRA del efecto
    # Mohring. Es una decisión de modelación, no un refinamiento pendiente: si
    # se toma, se toma con su ecuación.
    return TrainSupplyResult(
        t_acceso_min=t_acceso_min,
        t_espera_min=t_espera_min,
        t_viaje_min=t_viaje_min,
        frecuencia_operativa=f_op,
        frecuencia_teorica=f_teorica,
        carga_por_tramo=carga_por_tramo,
        estaciones_km=estaciones,
    )
