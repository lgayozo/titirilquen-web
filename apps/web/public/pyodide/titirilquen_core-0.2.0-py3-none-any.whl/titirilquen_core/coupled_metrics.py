"""Métricas del equilibrio de "Ciudad en equilibrio" (loop suelo ↔ transporte).

Calcula, a partir del `CoupledResult` final, un set de indicadores **por estrato**
(los "diferentes usuarios") y **del sistema** (el equilibrio agregado). Toda la
matemática vive aquí (política del repo); el frontend solo renderiza la tabla.

Reglas de procedencia de los datos (importante para interpretar):

- **Métricas de localización** (dónde vive cada estrato) salen del equilibrio de
  uso de suelo: `N_hi = S_i · Q[h,i]` (hogares esperados de `h` en la parcela
  `i`), suave y determinista.
- **Métricas de transporte** (tiempo, modo, costo, bienestar) salen de la
  **microdata** de agentes de la última corrida MSA, leyendo el tiempo del modo
  efectivamente elegido en el snapshot final.

Caveats de unidades (ver discusión en DISCREPANCIES.md / OVERLEAF_CHANGES.md):

- El **excedente del consumidor** (`delta_excedente_hogar_mes_clp`) usa el
  `E[max]` del agente convertido a $ con la utilidad marginal del dinero
  **propia de cada estrato** (`-b_costo_h`), por VIAJES_MES viajes: es mensual,
  la misma unidad que el arriendo, el ingreso y la tolerancia del acoplado (D11).
  Cuenta SÓLO transporte: la variación de rentas no entra, porque el nivel de
  precios del suelo no está anclado (`u[0] = 0`). Martínez (2018, §10.10,
  p. 264) muestra que el beneficio de los usuarios de transporte y la variación
  de rentas son, cada uno, una cota inferior del beneficio total, y que sumarlos
  sin cuidado cuenta dos veces lo mismo; esto es la primera cota.
  El `E[max]` es el logsum (`bienestar.logsum_de_utilidad`). Es comparable
  como *escala monetaria* (eficiencia / disposición a pagar), **no** como
  bienestar interpersonal: cada $1 vale distinto para un rico que para un pobre,
  y `b_costo` varía ~3,9 veces entre estratos. Para la lectura distributiva usar
  `carga_costo_ingreso` y el tiempo.
- Se reporta como **Δ contra la red vacía** (misma infraestructura con demanda
  cero: BPR(0) en auto/bici, tren a frecuencia mínima, mismas estaciones), no
  como nivel: el logsum incluye las ASC, así que el nivel absoluto tiene un
  cero arbitrario y no significa nada — solo las diferencias son
  interpretables. El signo es informativo: Δ < 0 ⇒ domina la congestión
  (demoras, espera, modos que dejan de ser factibles); Δ > 0 ⇒ domina el
  **efecto Mohring** (más demanda ⇒ más frecuencia de metro ⇒ menos espera que
  con la red vacía).
- Junto al Δ va el **nivel** (`excedente_hogar_mes_clp`, `excedente_total_mes_clp`),
  que solo sirve para restarlo entre dos escenarios. El Δ contra la red vacía
  compara cada escenario consigo mismo, y la red vacía fija sólo los TIEMPOS:
  los precios (peaje, parking, tarifa) entran igual en los dos términos y se
  cancelan, y en el acoplado cada hogar se evalúa donde quedó localizado en ese
  escenario. Restar esos Δ entre escenarios no da el cambio de bienestar entre
  ellos —un peaje no aparecería—. Restar niveles sí (Williams 1977; Small y
  Rosen 1981), siempre que los dos compartan β, modos habilitados, teletrabajo y
  medida: con otros β cambia la unidad; con otro menú o con otro teletrabajo,
  un hogar entra o sale de la suma con el cero arbitrario de las ASC.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any, cast

import numpy as np
from numpy.typing import NDArray

from titirilquen_core.bienestar import logsum_de_utilidad
from titirilquen_core.city import CiudadLineal
from titirilquen_core.config import SimulationConfig
from titirilquen_core.constantes import (
    CATEGORIAS_MODALES,
    MODOS,
    VIAJES_MES,
    CategoriaModal,
)
from titirilquen_core.demand.utility import TiemposObservados, costo_monetario_auto
from titirilquen_core.equilibrium.msa import ConvergenceTrace, IterationSnapshot
from titirilquen_core.land_use.accesibilidad import tiempos_red_vacia
from titirilquen_core.land_use.config import LandUseConfig
from titirilquen_core.land_use.equilibrium import LandUseResult

if TYPE_CHECKING:
    from titirilquen_core.config import StratumId


_MODOS_VIAJE: tuple[str, ...] = ("Auto", "Metro", "Bici", "Caminata")
# Categorías reportadas en el reparto modal (suman 1 sobre todos los agentes).
_CATEGORIAS_MODALES: tuple[str, ...] = CATEGORIAS_MODALES


@dataclass(frozen=True)
class StratumMetrics:
    """Indicadores de un estrato (un "tipo de usuario") en el equilibrio final."""

    estrato: int
    """1 = alto, 2 = medio, 3 = bajo."""

    n_hogares: float
    """Hogares del estrato (Σ_i S_i·Q[h,i] ≈ H_h)."""

    n_viajeros: int
    """Agentes del estrato que viajan (sin teletrabajo ni varados). Es la
    población sobre la que están promediados `tiempo_medio_min` y
    `costo_medio_clp`."""

    dist_media_cbd_km: float
    """Distancia media de residencia al CBD, ponderada por hogares (km)."""

    tiempo_medio_min: float
    """Tiempo de viaje medio de los agentes que viajan (min)."""

    reparto_modal: dict[CategoriaModal, float]
    """Share por categoría (Auto/Metro/Bici/Caminata/Teletrabajo/Varado); suma 1."""

    costo_medio_clp: float
    """Costo monetario medio del viaje, sobre los que viajan ($)."""

    delta_excedente_hogar_mes_clp: float
    """Δ excedente del consumidor vs la **red vacía**, en $/hogar-mes:
    VIAJES_MES·(logsum − logsum_0)/−b_costo por cada hogar que viaja, 0 por cada
    hogar que teletrabaja, promediado sobre ambos (los varados quedan fuera: no
    tienen medida). Hasta oct-2026 era $/viaje promediado sólo sobre los que
    viajan (D11). Δ<0 ⇒ costo neto de la congestión; Δ>0 ⇒ domina el efecto
    Mohring (frecuencia endógena). Eficiencia/DAP, NO bienestar interpersonal, y
    sin rentas — ver módulo docstring."""

    excedente_hogar_mes_clp: float
    """**Nivel** del excedente, en $/hogar-mes: VIAJES_MES·logsum/−b_costo, con
    el mismo denominador y la misma medida que `delta_excedente_hogar_mes_clp`.
    Su cero lo fijan las ASC: no se lee solo. Existe para restarlo entre DOS
    escenarios, que es el cambio de bienestar entre ellos; el Δ contra la red
    vacía no sirve para eso, porque los precios se cancelan dentro de él. Ver
    módulo docstring."""

    carga_costo_ingreso: float
    """Carga **mensual**: (costo medio por viaje · 44 viajes/mes) / ingreso
    mensual del estrato ($/mes). Fracción interpretable (~0.02–0.30) — antes
    mezclaba costo por viaje en $ con un ingreso adimensional (D-27)."""


@dataclass(frozen=True)
class SystemMetrics:
    """Indicadores del equilibrio agregado (todo el sistema)."""

    convergio_exterior: bool
    """¿El loop suelo↔transporte alcanzó `outer_tol`?"""

    iteraciones_exteriores: int
    residual_final: float | None
    """Brecha del loop exterior en la última iteración, `max_h |T_new − T|/λ_h`
    en $/hogar-mes (D10); None si no es medible (la primera iteración). Hasta
    oct-2026 iba en utiles de transporte por mes."""

    convergio_msa: bool
    """¿Convergió el MSA interior de la última corrida de transporte?"""

    tiempo_total_pax_min: float
    """Σ sobre agentes del tiempo de viaje (pax·min)."""

    tiempo_medio_min: float
    """Tiempo de viaje medio del sistema (min)."""

    reparto_modal: dict[CategoriaModal, float]
    """Reparto modal global (mismas categorías que por estrato; suma 1)."""

    frecuencia_metro: float
    """Frecuencia operativa del metro en el equilibrio (trenes/h)."""

    emisiones_total_kg: float
    emisiones_auto_kg: float
    emisiones_metro_kg: float

    segregacion_theil: float
    """Índice H de Theil sobre Q ∈ [0,1]. 0 = integrada, 1 = segregación total."""

    delta_bienestar_total_mes_clp: float
    """Σ sobre los hogares de ΔCS mensual ($/mes) — D-35, D11. Efecto agregado de
    bienestar de la demanda sobre la red (congestión vs Mohring), respecto a la
    red vacía. Sólo transporte: cota inferior en el sentido de Martínez p. 264."""

    excedente_total_mes_clp: float
    """**Nivel** del excedente de la ciudad, en $/mes: la misma suma que
    `delta_bienestar_total_mes_clp` sin restar la red vacía. Sólo su diferencia
    con otro escenario es interpretable, y sólo si comparten β, modos
    habilitados y teletrabajo (ver `excedente_hogar_mes_clp`)."""

    ratio_tiempo_bajo_alto: float | None
    """Tiempo medio bajo / alto. >1 ⇒ los pobres viajan más (regresivo)."""

    ratio_carga_bajo_alto: float | None
    """Carga (costo/ingreso) bajo / alto. >1 ⇒ el transporte pesa más al pobre."""


@dataclass(frozen=True)
class EquilibriumMetrics:
    """Reporte completo del equilibrio de Ciudad en equilibrio."""

    por_estrato: list[StratumMetrics]
    sistema: SystemMetrics


#: El mismo reporte ya convertido a dicts por `asdict`. Es un alias y no un
#: `TypedDict` a propósito: repetir los 20 campos acá sería reintroducir en
#: Python el espejo que se acaba de cerrar en TypeScript. El contrato TS se
#: genera desde las dataclasses de arriba, que son la única declaración.
EquilibriumMetricsJSON = dict[str, Any]


def equilibrium_metrics_to_dict(m: EquilibriumMetrics) -> EquilibriumMetricsJSON:
    """Serializa a un dict JSON-nativo (todos los campos son float/int/bool/str/dict).

    Es `asdict` sin más: la forma JSON **es** la de la dataclass. Por eso
    `tools/genera_contrato.py` emite las interfaces TypeScript desde estas
    dataclasses y no desde una copia — no hay dónde divergir.
    """
    return cast("EquilibriumMetricsJSON", asdict(m))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _tiempos_observados(snap: IterationSnapshot, i: int) -> TiemposObservados:
    """Reconstruye los tiempos observados de la celda `i` desde el snapshot final."""
    return TiemposObservados(
        auto_total=float(snap.t_auto[i]),
        bici_total=float(snap.t_bici[i]),
        bici_libre=float(snap.t_bici_libre[i]),
        tren_acceso=float(snap.t_tren_acceso[i]),
        tren_espera=float(snap.t_tren_espera[i]),
        tren_viaje=float(snap.t_tren_viaje[i]),
    )


def _tiempo_modo(
    snap: IterationSnapshot, modo: str, i: int, dist_km: float, v_caminata: float
) -> float:
    """Tiempo (min) del `modo` en la celda `i`, según el snapshot final."""
    if modo == "Auto":
        return float(snap.t_auto[i])
    if modo == "Metro":
        return float(snap.t_tren_acceso[i] + snap.t_tren_espera[i] + snap.t_tren_viaje[i])
    if modo == "Bici":
        return float(snap.t_bici[i])
    return dist_km / v_caminata * 60.0  # Caminata


def _costo_modo(modo: str, dist_km: float, gl, t_auto_min: float) -> float:
    """Costo monetario ($) del `modo` para un viaje de `dist_km`. El del auto
    depende de su tiempo de viaje: la bencina se quema según la velocidad."""
    if modo == "Auto":
        return costo_monetario_auto(dist_km, t_auto_min, gl)
    if modo == "Metro":
        return float(gl.costo_tarifa_metro)
    return 0.0  # Bici / Caminata


def _utilidad_esperada(
    tiempos: TiemposObservados,
    *,
    estrato: int,
    celda: int,
    tiene_auto: bool,
    ciudad: CiudadLineal,
    sim: SimulationConfig,
) -> float:
    """`E[max]` del agente en útiles: el logsum sobre sus modos factibles.

    Delega en `bienestar.logsum_de_utilidad`, que es la única implementación de
    la fórmula en el núcleo. Antes este módulo tenía su propia copia —con un
    filtro de factibilidad levemente distinto—.
    """
    ls = logsum_de_utilidad(
        estrato,  # type: ignore[arg-type]
        celda,
        tiene_auto,
        ciudad,
        sim,
        tiempos,
    )
    return float("nan") if ls is None else ls


def _theil(Q: np.ndarray, S: np.ndarray | None = None) -> float:
    """Índice H de Theil, 0 = integrada, 1 = segregada.

    Con `S` (capacidad por parcela) pesa por HOGARES, `N_hi = S_i·Q_hi`: es el
    índice poblacional (D-38). Sin `S` pesa cada celda habitada igual, porque
    las columnas de Q suman 1 — un índice territorial, no el que se reporta."""
    N_hi = Q if S is None else Q * np.asarray(S, dtype=float)[None, :]
    total_h = N_hi.sum(axis=1)
    total_i = N_hi.sum(axis=0)
    N = float(N_hi.sum())
    if N <= 0:
        return 0.0

    def entropy(p: np.ndarray) -> float:
        p = p[p > 0]
        return float(-(p * np.log(p)).sum())

    E = entropy(total_h / N)
    if E == 0:
        return 0.0
    weighted = 0.0
    for i in range(Q.shape[1]):
        Ni = total_i[i]
        if Ni <= 0:
            continue
        weighted += (Ni / N) * entropy(N_hi[:, i] / Ni)
    return 1.0 - weighted / E


# ---------------------------------------------------------------------------
# Cálculo principal
# ---------------------------------------------------------------------------


def compute_equilibrium_metrics(
    *,
    land_use: LandUseResult,
    trace: ConvergenceTrace,
    S: NDArray[np.float64] | NDArray[np.int_],
    sim: SimulationConfig,
    land_use_config: LandUseConfig,
    T_residual: float | None = None,
    converged: bool = False,
    iterations_count: int = 1,
) -> EquilibriumMetrics:
    """Calcula el reporte de métricas de un equilibrio (una OuterIteration).

    Recibe las piezas de la iteración (suelo, transporte y agentes mutuamente
    consistentes) y la oferta `S` (constante en el loop). Diseñada para llamarse
    por iteración exterior desde `coupled.py` y adjuntar el resultado a la
    `OuterIteration` — así viaja por el streaming sin recomputar.
    """
    lu = land_use
    snap = trace.iteraciones[-1]
    agentes = trace.agentes

    n_strata = lu.Q.shape[0]
    L = sim.city.n_celdas
    cbd = L // 2
    dx_km = sim.city.largo_ciudad_km / L
    ciudad = CiudadLineal(n_celdas=L, largo_total_km=sim.city.largo_ciudad_km)
    gl = sim.demand.globales

    S = np.asarray(S, dtype=float)
    Q = np.asarray(lu.Q, dtype=float)
    N = Q * S[None, :]  # N[h,i] = hogares esperados de h en parcela i
    dist = np.abs(np.arange(L) - cbd).astype(float) * dx_km

    ingresos = [float(s.y) for s in land_use_config.estratos]
    b_costo = [
        float(sim.demand.estratos[cast("StratumId", h + 1)].betas.b_costo) for h in range(n_strata)
    ]

    # --- Acumuladores de transporte por estrato (sobre agentes que viajan) ---
    t_sum = np.zeros(n_strata)
    c_sum = np.zeros(n_strata)
    cs_sum = np.zeros(n_strata)
    cs_nivel = np.zeros(n_strata)
    viajan = np.zeros(n_strata, dtype=int)
    modal = np.zeros((n_strata, len(_CATEGORIAS_MODALES)), dtype=float)
    total_ag = np.zeros(n_strata, dtype=int)
    cat_idx = {c: k for k, c in enumerate(_CATEGORIAS_MODALES)}

    # E[max] depende solo de (estrato, celda, tiene_auto): memoizar.
    # `cache_ff` es el baseline de red vacía del ΔCS (no depende del snapshot).
    cache_ls: dict[tuple[int, int, bool], float] = {}
    cache_ff: dict[tuple[int, int, bool], float] = {}
    tiempos_obs = [_tiempos_observados(snap, i) for i in range(L)]
    tiempos_ff = tiempos_red_vacia(sim, ciudad)

    for a in agentes:
        h = a.estrato - 1
        total_ag[h] += 1
        if a.teletrabaja:
            modal[h, cat_idx["Teletrabajo"]] += 1
            continue
        if a.modo_elegido is None:
            modal[h, cat_idx["Varado"]] += 1
            continue
        i = a.celda_origen
        key = (a.estrato, i, a.tiene_auto)
        ls = cache_ls.get(key)
        if ls is None:
            ls = _utilidad_esperada(
                tiempos_obs[i],
                estrato=a.estrato,
                celda=i,
                tiene_auto=a.tiene_auto,
                ciudad=ciudad,
                sim=sim,
            )
            cache_ls[key] = ls
        ls_ff = cache_ff.get(key)
        if ls_ff is None:
            ls_ff = _utilidad_esperada(
                tiempos_ff[i],
                estrato=a.estrato,
                celda=i,
                tiene_auto=a.tiene_auto,
                ciudad=ciudad,
                sim=sim,
            )
            cache_ff[key] = ls_ff
        # ΔCS vs red vacía: el nivel tiene cero arbitrario (ASC); solo la
        # diferencia es interpretable (congestión vs efecto Mohring).
        if not np.isnan(ls) and not np.isnan(ls_ff):
            cs_sum[h] += (ls - ls_ff) / (-b_costo[h])
            # El nivel, con la misma condición: así nivel y Δ suman sobre los
            # mismos agentes y el Δ entre escenarios sale de restar niveles.
            cs_nivel[h] += ls / (-b_costo[h])
        viajan[h] += 1

    # Reparto, tiempo y costo de los que viajan, desde la demanda ESPERADA por
    # (estrato, modo, celda) y no desde el `modo_elegido` sorteado de cada
    # agente: con carga esperada el sorteo sólo agrega ruido de muestreo
    # (auditoría C, ítem 9). Teletrabajo y varados no viajan: siguen siendo
    # conteos de agentes, que son exactos.
    assert trace.demanda_estrato is not None
    for h in range(n_strata):
        for m_idx, modo in enumerate(MODOS):
            dem = trace.demanda_estrato[h, m_idx]
            modal[h, cat_idx[modo]] += float(dem.sum())
            for i in np.flatnonzero(dem > 0):
                t_sum[h] += dem[i] * _tiempo_modo(snap, modo, int(i), dist[i], gl.v_caminata)
                c_sum[h] += dem[i] * _costo_modo(modo, dist[i], gl, float(snap.t_auto[i]))

    # --- Construir métricas por estrato ---
    por_estrato: list[StratumMetrics] = []
    for h in range(n_strata):
        n_h = float(N[h].sum())
        d_media = float((N[h] * dist).sum() / n_h) if n_h > 0 else 0.0
        nv = int(viajan[h])
        t_medio = float(t_sum[h] / nv) if nv > 0 else 0.0
        c_medio = float(c_sum[h] / nv) if nv > 0 else 0.0
        tot = int(total_ag[h])
        # ΔCS mensual por hogar (D11): quien teletrabaja no viaja y aporta 0; el
        # varado no tiene medida y queda fuera del denominador.
        con_medida = tot - int(modal[h, cat_idx["Varado"]])
        cs_hogar_mes = float(VIAJES_MES * cs_sum[h] / con_medida) if con_medida > 0 else 0.0
        nivel_hogar_mes = float(VIAJES_MES * cs_nivel[h] / con_medida) if con_medida > 0 else 0.0
        reparto = {c: (float(modal[h, k] / tot) if tot > 0 else 0.0) for c, k in cat_idx.items()}
        # Carga mensual: costo por viaje × viajes/mes sobre ingreso mensual (D-27).
        carga = (c_medio * VIAJES_MES) / ingresos[h] if ingresos[h] > 0 else 0.0
        por_estrato.append(
            StratumMetrics(
                estrato=h + 1,
                n_hogares=n_h,
                n_viajeros=nv,
                dist_media_cbd_km=d_media,
                tiempo_medio_min=t_medio,
                reparto_modal=reparto,
                costo_medio_clp=c_medio,
                delta_excedente_hogar_mes_clp=cs_hogar_mes,
                excedente_hogar_mes_clp=nivel_hogar_mes,
                carga_costo_ingreso=carga,
            )
        )

    # --- Métricas del sistema ---
    modal_global_counts = modal.sum(axis=0)
    tot_global = int(total_ag.sum())
    reparto_global = {
        c: (float(modal_global_counts[k] / tot_global) if tot_global > 0 else 0.0)
        for c, k in cat_idx.items()
    }
    t_total = float(t_sum.sum())
    n_viajan_total = int(viajan.sum())
    t_medio_sis = t_total / n_viajan_total if n_viajan_total > 0 else 0.0

    # Suma del ΔCS mensual sobre los agentes que VIAJAN (D-35, D11: ×VIAJES_MES,
    # en $/mes). Antes se multiplicaba el
    # promedio por viajero por `n_hogares` —que incluye teletrabajo y varados—,
    # inflando la magnitud ≈ n_hogares/n_viajeros (~20 % en la base). El
    # teletrabajador tiene ΔCS = 0; el varado no tiene medida y queda FUERA: si
    # una política deja gente sin viaje, este total no lo castiga (pendiente).
    bienestar_total = float(VIAJES_MES * cs_sum.sum())

    t_alto = por_estrato[0].tiempo_medio_min
    t_bajo = por_estrato[-1].tiempo_medio_min
    ratio_t = (t_bajo / t_alto) if t_alto > 0 else None
    carga_alto = por_estrato[0].carga_costo_ingreso
    carga_bajo = por_estrato[-1].carga_costo_ingreso
    ratio_carga = (carga_bajo / carga_alto) if carga_alto > 0 else None

    residual_out = None if T_residual is None or not np.isfinite(T_residual) else float(T_residual)

    sistema = SystemMetrics(
        convergio_exterior=converged,
        iteraciones_exteriores=iterations_count,
        residual_final=residual_out,
        convergio_msa=trace.converged,
        tiempo_total_pax_min=t_total,
        tiempo_medio_min=t_medio_sis,
        reparto_modal=reparto_global,
        frecuencia_metro=float(snap.frecuencia_metro),
        emisiones_total_kg=float(trace.emisiones_total_kg),
        emisiones_auto_kg=float(trace.emisiones_auto_kg),
        emisiones_metro_kg=float(trace.emisiones_metro_kg),
        segregacion_theil=_theil(Q, S),
        delta_bienestar_total_mes_clp=bienestar_total,
        excedente_total_mes_clp=float(VIAJES_MES * cs_nivel.sum()),
        ratio_tiempo_bajo_alto=ratio_t,
        ratio_carga_bajo_alto=ratio_carga,
    )

    return EquilibriumMetrics(por_estrato=por_estrato, sistema=sistema)
