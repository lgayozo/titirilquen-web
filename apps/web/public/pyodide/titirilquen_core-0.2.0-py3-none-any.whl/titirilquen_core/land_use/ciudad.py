"""Orquestador del uso de suelo — clase `LandUseCity`.

Reemplazo de la clase `Ciudad` de `titirilquen-repo/Ciudad2.py`, con API
explícita y separada de los helpers de transporte.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from numpy.typing import NDArray

from titirilquen_core.land_use.allocation import asignar_hogares_simple
from titirilquen_core.land_use.config import LandUseConfig
from titirilquen_core.land_use.equilibrium import LandUseResult, solve_subasta
from titirilquen_core.land_use.supply import generar_oferta

V_REF_KMH = 30.0
"""Velocidad de referencia del baseline "sin transporte": el T por defecto es
el tiempo a flujo libre a esta velocidad. Misma convención que el arranque del
loop acoplado (ver D-23/D-26)."""

ANCHO_CELDA_KM_DEFAULT = 0.1
"""Ancho de parcela por defecto ≈ ciudad de 20 km en 201 celdas, la referencia
del frontend.

Es una CONSTANTE y no dos literales porque los dos puntos de entrada de la
clase —el campo del dataclass y el parámetro de `build`— declaraban valores
distintos (0.1 y 0.01). Como `dens = S/Δx`, ese factor 10 es un factor 10 en la
desamenidad de densidad: entrar por `build()` sin pasar el ancho daba un
equilibrio distinto que construir la instancia directo. Los callers deben pasar
igual el ancho real (`largo_km / L`); el default existe para no romper los usos
de juguete.
"""


@dataclass
class LandUseCity:
    """Ciudad lineal con uso de suelo resuelto.

    Uso típico:
        city = LandUseCity.build(
            L=201, CBD=100, cfg=LandUseConfig(...),
            T=T_flujo_libre(demand, ...), lambda_h=lambda_desde_demanda(demand),
        )
        # T: accesibilidad mensual de transporte por estrato (obligatoria):
        city.update(T=T_from_transport)

    `T` y `lambda_h` vienen de la demanda (`land_use.accesibilidad`): el suelo
    no tiene config propia para ninguno de los dos (D-34, D-41, schema v6).
    """

    L: int
    cbd_index: int
    cfg: LandUseConfig
    # λ_h = |b_costo_h|, en utiles por peso. Ver `lambda_desde_demanda`.
    lambda_h: NDArray[np.float64]
    # Ancho físico de cada celda. Ver `ANCHO_CELDA_KM_DEFAULT`.
    ancho_celda_km: float = ANCHO_CELDA_KM_DEFAULT
    S: NDArray[np.int_] = field(default_factory=lambda: np.zeros(0, dtype=int))
    result: LandUseResult | None = None
    parcelas: list[list[int]] = field(default_factory=list)

    @classmethod
    def build(
        cls,
        *,
        L: int,
        CBD: int,
        cfg: LandUseConfig,
        ancho_celda_km: float = ANCHO_CELDA_KM_DEFAULT,
        S: NDArray[np.int_] | None = None,
        T: NDArray[np.float64] | None = None,
        lambda_h: NDArray[np.float64] | None = None,
        rng: np.random.Generator | None = None,
    ) -> LandUseCity:
        """Construye la ciudad, genera oferta si no se entrega, y resuelve equilibrio."""
        if lambda_h is None:
            raise ValueError(
                "LandUseCity necesita lambda_h: "
                "usá land_use.accesibilidad.lambda_desde_demanda(demand)"
            )
        lambda_h = np.asarray(lambda_h, dtype=float)
        if lambda_h.shape != (len(cfg.H_por_estrato),) or np.any(lambda_h <= 0):
            raise ValueError(f"lambda_h debe ser positivo, uno por estrato: {lambda_h}")
        if rng is None:
            rng = np.random.default_rng()
        N_total = int(sum(cfg.H_por_estrato))
        if S is None:
            S = generar_oferta(
                forma=cfg.forma,
                I=L,
                N=N_total,
                CBD=CBD,
                sigma_frac=cfg.oferta_sigma_frac,
                forma_param=cfg.forma_param,
            )
        if int(sum(S)) != N_total:
            raise ValueError(f"Σ S ({int(sum(S))}) ≠ Σ H ({N_total})")

        city = cls(
            L=L, cbd_index=CBD, cfg=cfg, lambda_h=lambda_h, ancho_celda_km=ancho_celda_km, S=S
        )
        city.update(T=T, rng=rng)
        return city

    def update(
        self,
        *,
        T: NDArray[np.float64] | None = None,
        rng: np.random.Generator | None = None,
    ) -> None:
        """Recalcula el equilibrio con la accesibilidad `T[h, i]` dada.

        `T` es obligatoria: es el logsum mensual de transporte por estrato
        (`land_use.accesibilidad`), y no hay un default honesto sin la demanda.
        Hasta sep-2026 existía `_default_T` (minutos a flujo libre); ver D-34."""
        if rng is None:
            rng = np.random.default_rng()

        H = np.asarray(self.cfg.H_por_estrato, dtype=int)
        n_strata = len(H)
        y = np.asarray([s.y for s in self.cfg.estratos], dtype=float)
        alpha = np.asarray([s.alpha for s in self.cfg.estratos], dtype=float)
        rho = np.asarray([s.rho for s in self.cfg.estratos], dtype=float)

        if T is None:
            raise ValueError(
                "LandUseCity necesita T[h, i]: "
                "usá land_use.accesibilidad.T_flujo_libre(demand, ...)"
            )
        if T.shape != (n_strata, self.L):
            raise ValueError(f"T shape {T.shape} != ({n_strata}, {self.L})")

        self.result = solve_subasta(
            H=H,
            S=self.S,
            y=y,
            T=T,
            alpha=alpha,
            rho=rho,
            lambda_h=self.lambda_h,
            mu=self.cfg.mu,
            tol=self.cfg.tol,
            max_iter=self.cfg.max_iter,
            ancho_celda_km=self.ancho_celda_km,
        )
        self.parcelas = asignar_hogares_simple(Q=self.result.Q, S=self.S, H=H, rng=rng)

    def densidad_por_celda(self) -> NDArray[np.float64]:
        """Densidad de población por celda (hab/km) como **consecuencia de la oferta
        `S`**:

            dens(i) = S_i / Δx

        donde `S_i` son los hogares que la ciudad ofrece en la celda `i`
        (`supply.generar_oferta`) y `Δx = ancho_celda_km`. La **forma** la da el
        perfil de oferta (`forma`); ya NO es un gradiente de Clark geométrico
        impuesto e independiente del equilibrio. Es **invariante a la grilla** (`S`
        escala con `Δx`, así que `S/Δx` no depende de la resolución) e
        **independiente del estrato** (la composición `Q` solo reparte esa
        población entre estratos, no fija su nivel). Las celdas sin oferta (el CBD,
        `S=0`) quedan en 0.

        Es la **misma envolvente** que usa la asignación de hogares
        (`asignar_hogares_simple` reparte `S·Q`), el feed a transporte y las
        figuras del frontend: una sola definición de "cuántos viven en la celda i"."""
        dens = np.asarray(self.S, dtype=float) / self.ancho_celda_km
        dens[np.asarray(self.S) <= 0] = 0.0  # sin vivienda (CBD)
        return dens

    def hogares_por_parcela_estrato(self) -> NDArray[np.int_]:
        """Matriz (n_strata, L) con el conteo efectivo asignado por celda."""
        n_strata = len(self.cfg.H_por_estrato)
        conteos = np.zeros((n_strata, self.L), dtype=int)
        for i, parcela in enumerate(self.parcelas):
            for h in parcela:
                conteos[h - 1, i] += 1
        return conteos
