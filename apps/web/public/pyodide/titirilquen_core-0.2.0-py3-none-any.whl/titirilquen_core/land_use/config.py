"""Esquemas Pydantic para el módulo de uso de suelo."""

from __future__ import annotations

import math

from pydantic import BaseModel, ConfigDict, Field, field_validator

from titirilquen_core.constantes import VIAJES_MES
from titirilquen_core.land_use.supply import FormaOferta

"""El modelo de subasta lo elige `solve_subasta` **según los datos**, no un campo
de configuración: con `λ_h` uniformes usa la forma cerrada de la ec. (4.26) de
Martínez, que ahí es exacta, y con `λ_h` heterogéneos usa HEV (`hev.py`), que es
el modelo correcto cuando la varianza de las pujas difiere entre estratos.

Existió un campo `solver` que ofrecía elegir, y uno de los métodos que ofrecía
decía corregir el artefacto de λ sin hacerlo (dejaba λ inerte). Se eliminó junto
con el campo, y no se repuso al implementar HEV justamente para que no se pueda
elegir el modelo inválido para la configuración dada. Un escenario guardado que
todavía traiga `solver` **no se migra**: falla al importar con un error
explícito, decisión tomada al romper la compatibilidad en agosto de 2026."""


class LandUseStratumConfig(BaseModel):
    """Parámetros de la función de puje (bid function) por estrato.

    **Unidades (D-26/D-27/D-34)**: `T` es el logsum mensual de transporte
    (utiles de transporte por mes) y la densidad va en hogares/km; `alpha` es
    adimensional (1 = la accesibilidad tal cual), `rho` en utiles-mes por
    (hogar/km) y `lambda` en utiles por peso (= |b_costo| de transporte), con
    lo que el score queda en $/mes. `y` está en $/mes (CLP); no mueve la
    asignación (se absorbe en ū, ver D-08) pero sí la métrica de carga mensual
    costo/ingreso del acoplado."""

    model_config = ConfigDict(extra="forbid")

    y: float = Field(gt=0, description="Ingreso mensual del estrato ($/mes)")
    lambda_: float = Field(
        default=1.0,
        gt=0,
        alias="lambda",
        description="Utilidad marginal del ingreso (λ_h)",
    )
    alpha: float = Field(
        default=1.0,
        description=(
            "Multiplicador de la accesibilidad (logsum mensual de transporte); 1 = tal cual"
        ),
    )
    rho: float = Field(
        default=0.0,
        ge=0,
        description=(
            "Penalización de densidad (utiles de transporte por mes, por hogar/km). "
            "0 = Alonso puro: sólo manda la accesibilidad. Entra en pesos como rho/lambda_h"
        ),
    )


class LandUseConfig(BaseModel):
    """Configuración del módulo de uso de suelo."""

    model_config = ConfigDict(extra="forbid")

    H_por_estrato: tuple[int, int, int] = Field(
        default=(33300, 33300, 33300),
        description="Número de hogares por estrato (alto, medio, bajo)",
    )
    # Hubo aquí un par `densidad_max` / `densidad_min` que se conservaba "por
    # compatibilidad de serialización" y que el propio `description` declaraba
    # vestigial: la densidad por celda es una CONSECUENCIA de la oferta
    # (dens = S/Δx, ver `LandUseCity.densidad_por_celda`), no un parámetro. La
    # escala de población la fija `H_por_estrato`. Se retiraron al romper la
    # compatibilidad de escenarios en agosto de 2026.
    #
    # OJO: ese comentario quedó pegado al campo de abajo en el espejo TypeScript
    # y terminó rotulando `estratos` como «VESTIGIAL (no usado)», que es lo
    # contrario de la verdad: `alpha` y `rho` son las dos palancas del bid-rent.
    # El `description` de acá existe para que el JSDoc generado lo diga.
    #
    # Calibración en unidades físicas (D-26). Ingresos en $/mes (D-27).
    #
    # `rho` = 0 por defecto: el modelo es Alonso puro, la localización la decide
    # sólo la accesibilidad y la segregación sale de que el tiempo vale distinto
    # por estrato. La penalización por densidad no tiene fuente (Martínez deja
    # f_h como función general de atributos) y actúa sobre una densidad exógena
    # (S/Δx), así que no es congestión residencial: es una desamenidad fija de la
    # parcela. Se conserva como dial pedagógico: como entra dividido por lambda_h,
    # un rho común ya hace que el estrato alto pague más pesos por baja densidad;
    # al subirlo, la ciudad se mezcla, el gradiente de renta se aplana y cerca de
    # 0,019 la asignación se invierte (el alto vive más lejos que el bajo), que es
    # el patrón «ricos en la periferia». La interfaz llega hasta 0,03.
    #
    # `lambda` HETEROGÉNEA (2026-09-02). Antes los tres valían 1,0, y eso no era
    # una decisión: era la única opción disponible. La forma cerrada de la
    # ec. (4.26) aplica un `β` escalar sobre las pujas, así que con ella
    # `lambda_h` sólo entra dividiendo el determinístico y es idénticamente
    # re-escalar `(alpha_h, rho_h)` por `1/lambda_h` — D-08. Con HEV el ruido
    # escala por estrato a `1/β_h = 1/(mu·lambda_h)`, que la re-escala de preferencias
    # no toca, y `lambda` queda IDENTIFICADO (`test_hev.py`).
    #
    # De dónde salen estos números (D-34, sep-2026). Un hogar tiene UNA función
    # de utilidad: el que puja por suelo es el que elige modo. Así que:
    #
    #   * `T_h(i)` = −VIAJES_MES·logsum_h(i): la utilidad esperada del viaje desde
    #     la parcela, en utiles de transporte, mensualizada (`accesibilidad.py`).
    #   * `alpha = 1`, común: la puja lee esa accesibilidad tal cual. Es el ancla
    #     que traía el original (`actualizar(T, alpha=[1,1,1])` sobre el logsum)
    #     y nunca se ejecutó. Un alpha ≠ 1 es un multiplicador sin fuente.
    #   * `lambda_h = |b_costo_h|` de `presets.DEFAULT_STRATA`, literal, en
    #     utiles de transporte por peso: 0,000320 / 0,000641 / 0,001241. Con eso
    #     el score `y + f/lambda` queda en $/mes, como `p` e `y` (D-27), el VoT
    #     `alpha/lambda` = 6.200 / 3.100 / 1.600 $/h coincide con transporte, y
    #     el ruido de la puja `1/(mu·lambda_h)` = $3.122 / $1.561 / $806 al mes.
    #   * `mu`: ver el comentario del campo, más abajo. Es la única perilla
    #     propia del módulo.
    #   * `rho`: sin fuente; 0 por defecto (ver el comentario del campo).
    #
    # Todo lo anterior está vigilado por `tests/test_vot_consistente.py` y
    # `tests/test_accesibilidad.py`. Historia: hasta sep-2026 alpha era 6,5/6,0/
    # 5,5 (el 1,3/1,2/1,1 del original ×5 por D-26), lambda = 1 por la forma
    # cerrada (D-08) y T minutos a flujo libre.
    estratos: tuple[LandUseStratumConfig, LandUseStratumConfig, LandUseStratumConfig] = Field(
        default=(
            LandUseStratumConfig(y=3_500_000.0, alpha=1.0, rho=0.0, **{"lambda": 0.000320323}),
            LandUseStratumConfig(y=1_500_000.0, alpha=1.0, rho=0.0, **{"lambda": 0.00064065}),
            LandUseStratumConfig(y=500_000.0, alpha=1.0, rho=0.0, **{"lambda": 0.00124125}),
        ),
        description=(
            "Parámetros de puja de los tres estratos (alto, medio, bajo). Son la "
            "palanca principal del módulo: `alpha` es común y la diferencia de "
            "`lambda` entre estratos fija el valor del tiempo `alpha/lambda` de "
            "cada uno, que es lo que produce el gradiente de Alonso."
        ),
    )

    # `mu` = 1/√VIAJES_MES ≈ 0,151. Es el `μ_h` de Martínez (2018, ec. 4.2), la
    # precisión del ruido de la UTILIDAD, común a los estratos; la de la puja en
    # dinero es `β_h = λ_h·μ` (ec. 4.3). Hasta sep-2026 este campo se llamaba
    # `beta`, que en Martínez es la otra precisión (schema v5, D-31).
    # Es la razón entre la escala del ruido de
    # elegir casa y la de elegir modo: el logit de transporte fija su escala en 1
    # (un útil = un shock Gumbel de un viaje), y la puja lee la accesibilidad
    # mensual, la suma de VIAJES_MES viajes. Si cada viaje trae su propio shock
    # independiente, la desviación del shock mensual crece como √VIAJES_MES, y la
    # escala del ruido de la puja, 1/(mu·lambda_h), tiene que crecer igual:
    # mu = 1/√VIAJES_MES. Es una aproximación de segundo momento (la suma de
    # Gumbel no es Gumbel) y un supuesto: en Martínez (2018, pp. 89 y 242) la
    # escala de la subasta se identifica con rentas observadas, que acá no hay.
    # mu = 1 sería «un solo shock por casa, igual al de un viaje», y da una
    # ciudad casi determinista (Theil ≈ 0,71 contra ≈ 0,17). Es la única
    # perilla propia del módulo: alpha y lambda vienen de transporte (D-34).
    @field_validator("H_por_estrato")
    @classmethod
    def _hogares_no_negativos(cls, v: tuple[int, int, int]) -> tuple[int, int, int]:
        # D-43: el schema aceptaba shares negativos, que aguas abajo dan
        # probabilidades inválidas sin ningún error explícito.
        if any(h < 0 for h in v):
            raise ValueError(f"H_por_estrato no admite negativos: {v}")
        if sum(v) <= 0:
            raise ValueError("H_por_estrato: la ciudad necesita al menos un hogar")
        return v

    mu: float = Field(
        default=1 / math.sqrt(VIAJES_MES),
        gt=0,
        description=(
            "μ de Martínez: precisión del ruido de la utilidad de localizarse, en 1 "
            "por útil. Es la razón entre la escala del ruido de elegir casa y la de "
            "un viaje; el ruido de la puja tiene escala 1/(mu·lambda) = 1/β_h. "
            "Default 1/√VIAJES_MES ≈ 0,151: "
            "el shock mensual acumula VIAJES_MES viajes independientes. 1 = un "
            "solo shock por casa (ciudad casi determinista)"
        ),
    )
    tol: float = Field(default=1e-8, gt=0)
    max_iter: int = Field(default=10000, ge=1)
    forma: FormaOferta = Field(
        default="normal",
        description=(
            "Forma del perfil de oferta de vivienda a lo largo del corredor: "
            "normal · uniforme · exponencial · meseta · bimodal · valle."
        ),
    )
    oferta_sigma_frac: float = Field(
        default=0.5,
        gt=0,
        le=1.5,
        description=(
            "Ancho/dispersión de la oferta como fracción de la semi-ciudad: "
            "σ = frac · min(CBD, L-1-CBD). Menor ⇒ ciudad compacta (vivienda junto "
            "al CBD); mayor ⇒ dispersa. También controla la pendiente de la "
            "exponencial y el ancho de los picos (bimodal). Default 0.5 = σ ≈ L/4."
        ),
    )
    forma_param: float = Field(
        default=0.5,
        ge=0,
        le=1,
        description=(
            "2º parámetro de la forma, como fracción de la semi-ciudad: separación "
            "de los picos (bimodal). Ignorado en las demás formas."
        ),
    )

    @field_validator("H_por_estrato")
    @classmethod
    def _check_positive(cls, v: tuple[int, int, int]) -> tuple[int, int, int]:
        if any(h <= 0 for h in v):
            raise ValueError("Todos los estratos deben tener al menos un hogar")
        return v
